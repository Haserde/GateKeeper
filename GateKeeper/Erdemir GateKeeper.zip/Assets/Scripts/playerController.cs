﻿using UnityEngine;
using System.Collections;

public class playerController : MonoBehaviour {

	public Rigidbody2D rb; 
	public float moveSpeed = 10f;
	public float jumpHeight = 20f;
	public bool doubleJump = false; 
	public bool grounded;
	public Animator anim; 
	float xScale;

	// Use this for initialization
	void Start () {
		rb = GetComponent<Rigidbody2D> ();
		anim = GetComponent<Animator> ();
		xScale = transform.localScale.x;
	}

	void OnCollisionStay2D(Collision2D coll){
		if (coll.gameObject.tag == "Ground") {
			grounded = true;
			anim.SetBool("Jump",false);
		}
	}
	void OnCollisionExit2D(Collision2D coll){
		if (coll.gameObject.tag == "Ground") {
			grounded = false;
			anim.SetBool("Jump",true);
		}
	}

	void OnTriggerStay2D(Collider2D coll){
		if (coll.gameObject.tag == "Platform") {
			transform.parent = coll.transform;
			grounded = true;
		}
	}

	void OnTriggerExit2D(Collider2D coll){
		if (coll.gameObject.tag == "Platform") {
			transform.parent = null;
			grounded = false;
		}
	}
		
	void FixedUpdate () {
		
		if (Input.GetAxis ("Horizontal") < 0) {
			transform.localScale = new Vector3 (-xScale, transform.localScale.y, transform.localScale.z);
		}
		if (Input.GetAxis ("Horizontal") > 0) {
			transform.localScale = new Vector3 (xScale, transform.localScale.y, transform.localScale.z);
		}
		
		if (Input.GetAxis("Horizontal") > 0 || Input.GetAxis ("Horizontal") < 0) {
			float moveX = Input.GetAxis ("Horizontal");
			rb.velocity = new Vector2 (moveX * moveSpeed, rb.velocity.y);
			anim.SetBool ("Walk", true);
		} else {
			anim.SetBool ("Walk", false);
		}

		if (Input.GetKeyDown(KeyCode.JoystickButton16)){
			if (grounded) {	
				rb.velocity = new Vector2(rb.velocity.x, 0);
				rb.AddForce (new Vector2 (0, jumpHeight));
				doubleJump = true;
			} else {

				if (doubleJump) {
					doubleJump = false; 
					rb.velocity = new Vector2 (rb.velocity.x, 0);
					rb.AddForce (new Vector2 (0, jumpHeight));
				}
			}
		}
	}
}
